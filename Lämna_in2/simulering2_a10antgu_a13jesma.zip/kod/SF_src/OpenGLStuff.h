#pragma once
/*
	To open the main window and start the rendering.
*/
void start(int argc, char* argv[]);


/*
	(c)2009 Henrik Engstr�m, henrik.engstrom@his.se
	This code may only be used by students in the Game Physics course at the University of Sk�vde 
	Contact me if you want to use it for other purposes.
*/